package com.example.speciesclassification;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageButton;

import androidx.appcompat.widget.SearchView;

import java.io.Serializable;
import java.util.ArrayList;

public class encyclopedia extends AppCompatActivity {

    private AutoCompleteTextView input;
    private ArrayList<Species> species;
    private ImageButton clear;
    private Button check;
    private ImageButton imgCheck;
    private Button advanced;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_encyclopedia);

        Intent intent = getIntent();
        species = (ArrayList<Species>) intent.getSerializableExtra("list");

        ArrayList<String>oldNames = new ArrayList<>();
        for(int i=0; i<species.size(); i++) {
            if(!species.get(i).getCName().equals("No accepted common name"))
                oldNames.add(species.get(i).getCName());
            oldNames.add(species.get(i).getSName());
        }
        final ArrayList<String> FINAL_NAMES = oldNames;

        String[] names = new String[FINAL_NAMES.size()];
        for(int i=0; i<FINAL_NAMES.size(); i++)
            names[i] = FINAL_NAMES.get(i);


        input = findViewById(R.id.actv_input);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,R.layout.suggestions,R.id.tv_suggest,names);
        input.setAdapter(adapter);

        advanced = findViewById(R.id.btn_advanced);
        advanced.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openAdvancedSearch();
            }
        });

        imgCheck = findViewById(R.id.btn_image);
        imgCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String INP = input.getText().toString().trim();
                openDefinitions(INP,FINAL_NAMES);
            }
        });
        check = findViewById(R.id.btn_getDef);
        check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String INP = input.getText().toString().trim();
                openDefinitions(INP,FINAL_NAMES);
            }
        });
        clear = findViewById(R.id.btn_clear);
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                input.setText("");
            }
        });
    }
    public void openDefinitions(String inp, ArrayList<String> FINAL_NAMES) {
        if(!FINAL_NAMES.contains(inp)) {
            AlertDialog.Builder builder = new AlertDialog.Builder(encyclopedia.this,R.style.dialogTheme);
            builder.setTitle("Unknown Species");
            builder.setMessage("Please Retype Name");
            AlertDialog alert = builder.create();
            alert.show();
        }
        else {
            Intent dictIntent = new Intent(encyclopedia.this,definition.class);
            dictIntent.putExtra("list",(Serializable)species);
            dictIntent.putExtra("name",inp);
            startActivity(dictIntent);
        }
    }
    public void openAdvancedSearch() {
        Intent advIntent = new Intent(encyclopedia.this,advancedSearch.class);
        advIntent.putExtra("list",(Serializable)species);
        startActivity(advIntent);
    }
}