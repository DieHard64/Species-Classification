package com.example.speciesclassification;

import java.io.Serializable;

public class Species implements Serializable {
    private String Taxon;
    private String SName;
    private String CName;
    private String USESA;
    private String SPROT;
    private String Endemic;
    private String GRank;
    private String SRank;
    private String SGCN;
    private String Description;
    private String Counties;

    public Species(String taxon, String SName, String CName, String USESA, String SPROT, String endemic, String GRank, String SRank, String SGCN, String description) {
        Taxon = taxon;
        this.SName = SName;
        this.CName = CName;
        this.USESA = USESA;
        this.SPROT = SPROT;
        Endemic = endemic;
        this.GRank = GRank;
        this.SRank = SRank;
        this.SGCN = SGCN;
        Description = description;
    }
    public String getTaxon() {
        return Taxon;
    }

    public void setTaxon(String taxon) {
        Taxon = taxon;
    }

    public String getSName() {
        return SName;
    }

    public void setSName(String SName) {
        this.SName = SName;
    }

    public String getCName() {
        return CName;
    }

    public void setCName(String CName) {
        this.CName = CName;
    }

    public String getUSESA() {
        return USESA;
    }

    public void setUSESA(String USESA) {
        this.USESA = USESA;
    }

    public String getSPROT() {
        return SPROT;
    }

    public void setSPROT(String SPROT) {
        this.SPROT = SPROT;
    }

    public String getEndemic() {
        return Endemic;
    }

    public void setEndemic(String endemic) {
        Endemic = endemic;
    }

    public String getGRank() {
        return GRank;
    }

    public void setGRank(String GRank) {
        this.GRank = GRank;
    }

    public String getSRank() {
        return SRank;
    }

    public void setSRank(String SRank) {
        this.SRank = SRank;
    }

    public String getSGCN() {
        return SGCN;
    }

    public void setSGCN(String SGCN) {
        this.SGCN = SGCN;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public String getCounties() {
        return Counties;
    }

    public void setCounties(String counties) {
        Counties = counties;
    }

}
