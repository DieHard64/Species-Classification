package com.example.speciesclassification;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.SimpleCursorAdapter;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;

public class MainActivity extends AppCompatActivity {

    private Button capture;
    private Button encyclopedia;

    private ArrayList<Species> species;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        species = new ArrayList<>();

        capture = findViewById(R.id.btn_capture);
        encyclopedia =  findViewById(R.id.btn_encyclopedia);

        readSpeciesData();

        capture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openCaption();
            }
        });

        encyclopedia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openEncyclopedia();
            }
        });
    }
    public void openEncyclopedia() {
        Intent intent = new Intent(MainActivity.this, encyclopedia.class);
        intent.putExtra("list",(Serializable)species);
        startActivity(intent);
    }
    public void openCaption() {
        Intent intent = new Intent(MainActivity.this, caption.class);
        intent.putExtra("list",(Serializable)species);
        startActivity(intent);
    }
    public void readSpeciesData(){
        InputStream input = getResources().openRawResource(R.raw.county_species_records);
        BufferedReader br = new BufferedReader(new InputStreamReader(input, Charset.forName("UTF-8")));
        String str = null;
        try {
            while((str=br.readLine())!=null) {
                String[] section = str.split(",");
                for(int i=0; i<section.length; i++)
                    if(section[i].equals(""))
                        section[i] = "Unavailable or Not Applicable";
                Species animal = new Species(section[0],section[1],section[2],section[3],section[4],
                        section[5],section[6],section[7],section[8],section[9]);
                if(section.length==10)
                    animal.setCounties("Unavailable or Not Applicable");
                else
                    animal.setCounties(section[10]);
                species.add(animal);
            }
            Collections.sort(species);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}