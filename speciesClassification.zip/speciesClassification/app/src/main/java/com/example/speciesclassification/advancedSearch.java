package com.example.speciesclassification;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.TextView;

import java.io.Serializable;
import java.util.ArrayList;

public class advancedSearch extends AppCompatActivity {

    private AutoCompleteTextView input2;
    private ArrayList<Species> species;
    private ImageButton clear2;
    private ImageButton imgCheck2;
    private TextView tv_results;
    private Button home;
    private Button btn_clearTaxon;
    private ImageButton btn_help;
    private AlertDialog alertDialog;
    private AlertDialog.Builder builder;

    private CheckBox cb_amphibians;
    private CheckBox cb_birds;
    private CheckBox cb_fish;
    private CheckBox cb_mammals;
    private CheckBox cb_reptiles;
    private CheckBox cb_crustaceans;
    private CheckBox cb_insects;
    private CheckBox cb_arachnids;
    private CheckBox cb_mollusks;
    private CheckBox cb_arthropods;

    private boolean amphibians = false;
    private boolean birds = false;
    private boolean fish = false;
    private boolean mammals = false;
    private boolean reptiles = false;
    private boolean crustaceans = false;
    private boolean insects = false;
    private boolean arachnids = false;
    private boolean mollusks = false;
    private boolean arthropods = false;

    private CheckBox cb_LE;
    private CheckBox cb_LT;
    private CheckBox cb_E;
    private CheckBox cb_T;
    private CheckBox cb_Yes;
    private CheckBox cb_No;
    private CheckBox cb_qual;
    private CheckBox cb_notQual;

    private boolean LE = false;
    private boolean LT = false;
    private boolean E = false;
    private boolean T = false;
    private boolean Yes = false;
    private boolean No = false;
    private boolean qual = false;
    private boolean notQual = false;

    private ArrayList<Species> newList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_advanced_search);

        tv_results = findViewById(R.id.tv_results);

        Intent intent = getIntent();
        species = (ArrayList<Species>) intent.getSerializableExtra("list");
        newList = new ArrayList<>();

        input2 = findViewById(R.id.actv_input2);

        imgCheck2 = findViewById(R.id.btn_image2);
        imgCheck2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String INP = input2.getText().toString().trim();
                ArrayList<String> FINAL_NAMES = getList();
                openDefinitions(INP,FINAL_NAMES);
            }
        });

        clear2 = findViewById(R.id.btn_clear2);
        clear2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                input2.setText("");
            }
        });

        home = findViewById(R.id.btn_home);
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent homeIntent = new Intent(advancedSearch.this,MainActivity.class);
                startActivity(homeIntent);
            }
        });

        cb_amphibians = findViewById(R.id.cb_amphibians);
        cb_amphibians.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(cb_amphibians.isChecked()) amphibians = true;
                else amphibians = false;
                recreateList(amphibians,birds,fish,mammals,reptiles,crustaceans,insects,arachnids,mollusks,arthropods,LE,LT,E,T,Yes,No,qual,notQual);
            }
        });
        cb_birds = findViewById(R.id.cb_birds);
        cb_birds.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(cb_birds.isChecked()) birds = true;
                else birds = false;
                recreateList(amphibians,birds,fish,mammals,reptiles,crustaceans,insects,arachnids,mollusks,arthropods,LE,LT,E,T,Yes,No,qual,notQual);
            }
        });
        cb_fish = findViewById(R.id.cb_fish);
        cb_fish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(cb_fish.isChecked()) fish = true;
                else fish = false;
                recreateList(amphibians,birds,fish,mammals,reptiles,crustaceans,insects,arachnids,mollusks,arthropods,LE,LT,E,T,Yes,No,qual,notQual);
            }
        });
        cb_mammals = findViewById(R.id.cb_mammals);
        cb_mammals.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(cb_mammals.isChecked()) mammals = true;
                else mammals = false;
                recreateList(amphibians,birds,fish,mammals,reptiles,crustaceans,insects,arachnids,mollusks,arthropods,LE,LT,E,T,Yes,No,qual,notQual);
            }
        });
        cb_reptiles = findViewById(R.id.cb_reptiles);
        cb_reptiles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(cb_reptiles.isChecked()) reptiles = true;
                else reptiles = false;
                recreateList(amphibians,birds,fish,mammals,reptiles,crustaceans,insects,arachnids,mollusks,arthropods,LE,LT,E,T,Yes,No,qual,notQual);
            }
        });
        cb_crustaceans = findViewById(R.id.cb_crustaceans);
        cb_crustaceans.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(cb_crustaceans.isChecked()) crustaceans = true;
                else crustaceans = false;
                recreateList(amphibians,birds,fish,mammals,reptiles,crustaceans,insects,arachnids,mollusks,arthropods,LE,LT,E,T,Yes,No,qual,notQual);
            }
        });
        cb_insects = findViewById(R.id.cb_insects);
        cb_insects.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(cb_insects.isChecked()) insects = true;
                else insects = false;
                recreateList(amphibians,birds,fish,mammals,reptiles,crustaceans,insects,arachnids,mollusks,arthropods,LE,LT,E,T,Yes,No,qual,notQual);
            }
        });
        cb_arachnids = findViewById(R.id.cb_arachnids);
        cb_arachnids.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(cb_arachnids.isChecked()) arachnids = true;
                else arachnids = false;
                recreateList(amphibians,birds,fish,mammals,reptiles,crustaceans,insects,arachnids,mollusks,arthropods,LE,LT,E,T,Yes,No,qual,notQual);
            }
        });
        cb_mollusks = findViewById(R.id.cb_mollusks);
        cb_mollusks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(cb_mollusks.isChecked()) mollusks = true;
                else mollusks = false;
                recreateList(amphibians,birds,fish,mammals,reptiles,crustaceans,insects,arachnids,mollusks,arthropods,LE,LT,E,T,Yes,No,qual,notQual);
            }
        });
        cb_arthropods = findViewById(R.id.cb_arthropods);
        cb_arthropods.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(cb_arthropods.isChecked()) arthropods = true;
                else arthropods = false;
                recreateList(amphibians,birds,fish,mammals,reptiles,crustaceans,insects,arachnids,mollusks,arthropods,LE,LT,E,T,Yes,No,qual,notQual);
            }
        });

        cb_LE = findViewById(R.id.cb_federalEndanger);
        cb_LE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(cb_LE.isChecked()) LE = true;
                else LE = false;
                recreateList(amphibians,birds,fish,mammals,reptiles,crustaceans,insects,arachnids,mollusks,arthropods,LE,LT,E,T,Yes,No,qual,notQual);
            }
        });
        cb_LT = findViewById(R.id.cb_federalThreat);
        cb_LT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(cb_LT.isChecked()) LT = true;
                else LT = false;
                recreateList(amphibians,birds,fish,mammals,reptiles,crustaceans,insects,arachnids,mollusks,arthropods,LE,LT,E,T,Yes,No,qual,notQual);
            }
        });
        cb_E = findViewById(R.id.cb_stateEndanger);
        cb_E.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(cb_E.isChecked()) E = true;
                else E = false;
                recreateList(amphibians,birds,fish,mammals,reptiles,crustaceans,insects,arachnids,mollusks,arthropods,LE,LT,E,T,Yes,No,qual,notQual);
            }
        });
        cb_T = findViewById(R.id.cb_stateThreat);
        cb_T.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(cb_T.isChecked()) T = true;
                else T = false;
                recreateList(amphibians,birds,fish,mammals,reptiles,crustaceans,insects,arachnids,mollusks,arthropods,LE,LT,E,T,Yes,No,qual,notQual);
            }
        });
        cb_Yes = findViewById(R.id.cb_endemicYes);
        cb_Yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(cb_Yes.isChecked()) Yes = true;
                else Yes = false;
                recreateList(amphibians,birds,fish,mammals,reptiles,crustaceans,insects,arachnids,mollusks,arthropods,LE,LT,E,T,Yes,No,qual,notQual);
            }
        });
        cb_No = findViewById(R.id.cb_endemicNo);
        cb_No.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(cb_No.isChecked()) No = true;
                else No = false;
                recreateList(amphibians,birds,fish,mammals,reptiles,crustaceans,insects,arachnids,mollusks,arthropods,LE,LT,E,T,Yes,No,qual,notQual);
            }
        });
        cb_qual = findViewById(R.id.cb_SGCNQual);
        cb_qual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(cb_qual.isChecked()) qual = true;
                else qual = false;
                recreateList(amphibians,birds,fish,mammals,reptiles,crustaceans,insects,arachnids,mollusks,arthropods,LE,LT,E,T,Yes,No,qual,notQual);
            }
        });
        cb_notQual = findViewById(R.id.cb_SGCNnotQual);
        cb_notQual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(cb_notQual.isChecked()) notQual = true;
                else notQual = false;
                recreateList(amphibians,birds,fish,mammals,reptiles,crustaceans,insects,arachnids,mollusks,arthropods,LE,LT,E,T,Yes,No,qual,notQual);
            }
        });
        btn_clearTaxon = findViewById(R.id.btn_clearTaxon);
        btn_clearTaxon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cb_amphibians.setChecked(false);
                cb_birds.setChecked(false);
                cb_fish.setChecked(false);
                cb_mammals.setChecked(false);
                cb_reptiles.setChecked(false);
                cb_crustaceans.setChecked(false);
                cb_insects.setChecked(false);
                cb_arachnids.setChecked(false);
                cb_mollusks.setChecked(false);
                cb_arthropods.setChecked(false);
                amphibians = false;
                birds = false;
                fish = false;
                mammals = false;
                reptiles = false;
                crustaceans = false;
                insects = false;
                arachnids = false;
                mollusks = false;
                arthropods = false;
                recreateList(amphibians,birds,fish,mammals,reptiles,crustaceans,insects,arachnids,mollusks,arthropods,LE,LT,E,T,Yes,No,qual,notQual);
            }
        });
        btn_help = findViewById(R.id.btn_help);
        btn_help.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDialog();
            }
        });
    }
    public void openDialog() {
        builder = new AlertDialog.Builder(advancedSearch.this);
        View view = getLayoutInflater().inflate(R.layout.extra_info,null);
        TextView tv_info = view.findViewById(R.id.tv_info);
        tv_info.setText(getResources().getString(R.string.search_help));
        builder.setView(view);
        alertDialog= builder.create();
        alertDialog.setTitle("Advanced Search Help");
        alertDialog.show();
        alertDialog.getWindow().setLayout(400,500);
    }
    public ArrayList<String> getList() {
        ArrayList<String>oldNames = new ArrayList<>();
        for(int i=0; i<newList.size(); i++) {
            oldNames.add(newList.get(i).getSName());
        }
        return oldNames;
    }
    public void recreateSV() {
        String[] names = new String[newList.size()];
        for(int i=0; i<newList.size(); i++)
            names[i] = newList.get(i).getSName();
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,R.layout.suggestions,R.id.tv_suggest,names);
        input2.setAdapter(adapter);
    }
    public void openDefinitions(String inp, ArrayList<String> FINAL_NAMES) {
        if(!FINAL_NAMES.contains(inp)) {
            AlertDialog.Builder builder = new AlertDialog.Builder(advancedSearch.this,R.style.dialogTheme);
            builder.setTitle("0 Species Match the Constraints");
            builder.setMessage("Retry Constraints");
            AlertDialog alert = builder.create();
            alert.show();
        }
        else {
            Intent dictIntent = new Intent(advancedSearch.this,definition.class);
            dictIntent.putExtra("list",(Serializable)species);
            dictIntent.putExtra("name",inp);
            startActivity(dictIntent);
        }
    }
    public void recreateList(boolean amphibians,boolean birds,boolean fish,boolean mammals,boolean
            reptiles,boolean crustaceans,boolean insects,boolean arachnids,boolean mollusks,boolean arthropods,
                             boolean LE,boolean LT,boolean E,boolean T,boolean Yes,boolean No,boolean qual,boolean notQual) {
        newList.clear();
        if(amphibians) newList = addAnimal(newList,"Amphibians");
        if(birds) newList = addAnimal(newList,"Birds");
        if(fish) newList = addAnimal(newList,"Fish");
        if(mammals) newList = addAnimal(newList,"Mammals");
        if(reptiles) newList = addAnimal(newList,"Reptiles");
        if(crustaceans) newList = addAnimal(newList,"Crustaceans");
        if(insects) newList = addAnimal(newList,"Insects");
        if(arachnids) newList = addAnimal(newList,"Arachnids");
        if(mollusks) newList = addAnimal(newList,"Mollusks");
        if(arthropods) newList = addAnimal(newList,"Arthropods");

        boolean edited = false;
        if(!(newList.size()==0)) edited=true;
        if(LE&&LT&&!edited) newList = addUSESA(newList,"LE","LT");
        else if(LE&&LT) newList = addUSESAadvanced(newList,"LE","LT");
        else if(LE&&!edited) newList = addUSESA(newList,"LE","-1");
        else if(LT&&!edited) newList = addUSESA(newList,"LT","-1");
        else if(LE) newList = addUSESAadvanced(newList,"LE","-1");
        else if(LT) newList = addUSESAadvanced(newList,"LT","-1");

        boolean edited2 = false;
        if(edited==true||!(newList.size()==0)) edited2=true;
        if(E&&T&&!edited2) newList = addSPROT(newList,"E","T");
        else if(E&&T) newList = addSPROTadvanced(newList,"E","T");
        else if(E&&!edited2) newList = addSPROT(newList,"E","-1");
        else if(T&&!edited2) newList = addSPROT(newList,"T","-1");
        else if(E) newList = addSPROTadvanced(newList,"E","-1");
        else if(T) newList = addSPROTadvanced(newList,"T","-1");

        boolean edited3 = false;
        if(edited2==true||!(newList.size()==0)) edited3=true;
        if(Yes&&No&&!edited3) newList = addEndemic(newList,"Y","N");
        else if(Yes&&No) newList = addEndemicadvanced(newList,"Y","N");
        else if(Yes&&!edited3) newList = addEndemic(newList,"Y","-1");
        else if(No&&!edited3) newList = addEndemic(newList,"N","-1");
        else if(Yes) newList = addEndemicadvanced(newList,"Y","-1");
        else if(No) newList = addEndemicadvanced(newList,"N","-1");

        boolean edited4 = false;
        if(edited3==true||!(newList.size()==0)) edited4=true;
        if(qual&&notQual&&!edited4) newList = addSGCN(newList,"Y","N");
        else if(qual&&notQual) newList = addSGCNadvanced(newList,"Y","N");
        else if(qual&&!edited4) newList = addSGCN(newList,"Y","-1");
        else if(notQual&&!edited4) newList = addSGCN(newList,"N","-1");
        else if(qual) newList = addSGCNadvanced(newList,"Y","-1");
        else if(notQual) newList = addSGCNadvanced(newList,"N","-1");

        String output = "";
        for(int i=0; i<newList.size(); i++) {
            output = output+(i+1)+". "+newList.get(i).getSName()+"\n";
        }
        tv_results.setText(output);
        recreateSV();
    }



    public ArrayList<Species> addAnimal(ArrayList<Species> newList, String taxon) {
        for(int i=0; i<species.size(); i++)
            if(species.get(i).getTaxon().equals(taxon)) newList.add(species.get(i));
        return newList;
    }
    public ArrayList<Species> addUSESA(ArrayList<Species> newList, String USESA1, String USESA2) {
        for(int i=0; i<species.size(); i++)
            if(species.get(i).getUSESA().equals(USESA1) || species.get(i).getUSESA().equals(USESA2)) newList.add(species.get(i));
        return newList;
    }

    public ArrayList<Species> addUSESAadvanced(ArrayList<Species> newList, String USESA1, String USESA2) {
        ArrayList<Species> newestList = new ArrayList<>();
        for(int i=0; i<newList.size(); i++)
            if(newList.get(i).getUSESA().equals(USESA1)||newList.get(i).getUSESA().equals(USESA2)) newestList.add(newList.get(i));
        return newestList;
    }

    public ArrayList<Species> addSPROT(ArrayList<Species> newList, String SPROT1, String SPROT2) {
        for(int i=0; i<species.size(); i++)
            if(species.get(i).getSPROT().equals(SPROT1) || species.get(i).getSPROT().equals(SPROT2)) newList.add(species.get(i));
        return newList;
    }
    public ArrayList<Species> addSPROTadvanced(ArrayList<Species> newList, String SPROT1, String SPROT2) {
        ArrayList<Species> newestList = new ArrayList<>();
        for(int i=0; i<newList.size(); i++)
            if(newList.get(i).getSPROT().equals(SPROT1)||newList.get(i).getSPROT().equals(SPROT2)) newestList.add(newList.get(i));
        return newestList;
    }

    public ArrayList<Species> addEndemic(ArrayList<Species> newList, String Endemic1, String Endemic2) {
        for(int i=0; i<species.size(); i++)
            if(species.get(i).getEndemic().equals(Endemic1) || species.get(i).getEndemic().equals(Endemic2)) newList.add(species.get(i));
        return newList;
    }
    public ArrayList<Species> addEndemicadvanced(ArrayList<Species> newList, String Endemic1, String Endemic2) {
        ArrayList<Species> newestList = new ArrayList<>();
        for(int i=0; i<newList.size(); i++)
            if(newList.get(i).getEndemic().equals(Endemic1)||newList.get(i).getEndemic().equals(Endemic2)) newestList.add(newList.get(i));
        return newestList;
    }

    public ArrayList<Species> addSGCN(ArrayList<Species> newList, String SGCN1, String SGCN2) {
        for(int i=0; i<species.size(); i++)
            if(species.get(i).getSGCN().equals(SGCN1) || species.get(i).getSGCN().equals(SGCN2)) newList.add(species.get(i));
        return newList;
    }
    public ArrayList<Species> addSGCNadvanced(ArrayList<Species> newList, String SGCN1, String SGCN2) {
        ArrayList<Species> newestList = new ArrayList<>();
        for(int i=0; i<newList.size(); i++)
            if(newList.get(i).getSGCN().equals(SGCN1)||newList.get(i).getSGCN().equals(SGCN2)) newestList.add(newList.get(i));
        return newestList;
    }
}