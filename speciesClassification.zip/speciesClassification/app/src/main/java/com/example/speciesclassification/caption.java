package com.example.speciesclassification;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import java.io.Serializable;
import java.util.ArrayList;

public class caption extends AppCompatActivity {

    private ArrayList<Species> species;
    private ImageButton btn_class1;
    private ImageButton btn_class2;
    private ImageButton btn_class3;

    private TextView tv_name1;
    private TextView tv_name2;
    private TextView tv_name3;
    private TextView tv_pctg1;
    private TextView tv_pctg2;
    private TextView tv_pctg3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_caption);

        Intent intent = getIntent();
        species = (ArrayList<Species>) intent.getSerializableExtra("list");

        tv_name1 = findViewById(R.id.tv_name1);
        tv_name2 = findViewById(R.id.tv_name2);
        tv_name3 = findViewById(R.id.tv_name3);
        tv_pctg1 = findViewById(R.id.tv_pctg1);
        tv_pctg2 = findViewById(R.id.tv_pctg2);
        tv_pctg3 = findViewById(R.id.tv_pctg3);

        btn_class1 = findViewById(R.id.btn_class1);
        btn_class2 = findViewById(R.id.btn_class2);
        btn_class3 = findViewById(R.id.btn_class3);

        btn_class1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDefinitions(tv_name1.getText().toString());
            }
        });
        btn_class2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDefinitions(tv_name2.getText().toString());
            }
        });
        btn_class3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDefinitions(tv_name3.getText().toString());
            }
        });
    }
    public void openDefinitions(String inp) {
        boolean included = false;
        for (int i=0; i<species.size(); i++)
            if(species.get(i).getSName().equals(inp)) included = true;
        if(!included) {
            AlertDialog.Builder builder = new AlertDialog.Builder(caption.this,R.style.dialogTheme);
            builder.setTitle("Error With Name");
            builder.setMessage("Please Retake Image");
            AlertDialog alert = builder.create();
            alert.show();
        }
        else {
            Intent dictIntent = new Intent(caption.this,definition.class);
            dictIntent.putExtra("list",(Serializable)species);
            dictIntent.putExtra("name",inp);
            startActivity(dictIntent);
        }
    }
}