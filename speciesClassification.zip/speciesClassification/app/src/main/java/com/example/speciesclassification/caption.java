package com.example.speciesclassification;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.util.Pair;

import android.Manifest;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.soundcloud.android.crop.Crop;

import org.tensorflow.lite.Interpreter;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Serializable;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class caption extends AppCompatActivity {

    private ImageView imgDisplay;

    private ArrayList<Species> species;
    private ImageButton btn_class1;
    private ImageButton btn_class2;
    private ImageButton btn_class3;
    private Button btn_classify;

    private ArrayList<String> labelList;

    private TextView[][] outLabels;
    private TextView tv_name1;
    private TextView tv_name2;
    private TextView tv_name3;
    private TextView tv_pctg1;
    private TextView tv_pctg2;
    private TextView tv_pctg3;

    private Interpreter tflite;
    private Uri imageUri;
    public static final int REQUEST_IMAGE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_caption);

        requestPermissions();

        Intent intent = getIntent();
        species = (ArrayList<Species>) intent.getSerializableExtra("list");

        tv_name1 = findViewById(R.id.tv_name1);
        tv_name2 = findViewById(R.id.tv_name2);
        tv_name3 = findViewById(R.id.tv_name3);
        tv_pctg1 = findViewById(R.id.tv_pctg1);
        tv_pctg2 = findViewById(R.id.tv_pctg2);
        tv_pctg3 = findViewById(R.id.tv_pctg3);
        outLabels = new TextView[][]{
                {tv_name1, tv_pctg1},
                {tv_name2, tv_pctg2},
                {tv_name1, tv_pctg3}
        };

        btn_class1 = findViewById(R.id.btn_class1);
        btn_class2 = findViewById(R.id.btn_class2);
        btn_class3 = findViewById(R.id.btn_class3);
        btn_classify = findViewById(R.id.btn_classify);

        imgDisplay = findViewById(R.id.img_display);

        try{
            tflite = new Interpreter(Helper.loadModelFile(this.getAssets()), new Interpreter.Options());
            labelList = Helper.loadLabelList(this.getAssets());
        }catch (IOException e) {
            e.printStackTrace();
        }

        btn_classify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCameraIntent();
            }
        });

        btn_class1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDefinitions(tv_name1.getText().toString());
            }
        });
        btn_class2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDefinitions(tv_name2.getText().toString());
            }
        });
        btn_class3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDefinitions(tv_name3.getText().toString());
            }
        });
    }
    public void openDefinitions(String inp) {
        boolean included = false;
        for (int i=0; i<species.size(); i++)
            if(species.get(i).getSName().equals(inp)) included = true;
        if(!included) {
            AlertDialog.Builder builder = new AlertDialog.Builder(caption.this,R.style.dialogTheme);
            builder.setTitle("Error With Name");
            builder.setMessage("Please Retake Image");
            AlertDialog alert = builder.create();
            alert.show();
        }
        else {
            Intent dictIntent = new Intent(caption.this,definition.class);
            dictIntent.putExtra("list",(Serializable)species);
            dictIntent.putExtra("name",inp);
            startActivity(dictIntent);
        }
    }

    private void openCameraIntent() {
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.TITLE, "New Picture");
        values.put(MediaStore.Images.Media.DESCRIPTION, "From Your Camera");

        imageUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        startActivityForResult(intent, REQUEST_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == REQUEST_IMAGE && resultCode == RESULT_OK) {
            try {
                Uri source_uri = imageUri;
                Uri dest_uri = Uri.fromFile(new File(getCacheDir(), "cropped"));
                Crop.of(source_uri, dest_uri).asSquare().start(this);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (requestCode == Crop.REQUEST_CROP && resultCode == RESULT_OK) {
            classifyModel(Crop.getOutput(data));
        }
    }

    private void classifyModel(Uri uri) {
        int imageSizeX = Helper.DIM_IMG_SIZE_X;
        int imageSizeY = Helper.DIM_IMG_SIZE_Y;
        int imagePixelSize = Helper.DIM_PIXEL_SIZE;

        int[] imgArray = new int[imageSizeX * imageSizeY];

        ByteBuffer imgData =  ByteBuffer.allocateDirect(4 * imageSizeX * imageSizeY * imagePixelSize);
        imgData.order(ByteOrder.nativeOrder());

        float[][] labelProbArray = new float[1][labelList.size()];

        try {
            Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
            imgDisplay.setImageBitmap(bitmap);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        Bitmap bitmap_orig = ((BitmapDrawable) imgDisplay.getDrawable()).getBitmap();
        Bitmap bitmap = Helper.getResizedBitmap(bitmap_orig, imageSizeX, imageSizeY);
        imgData = Helper.convertBitmapToByteBuffer(bitmap, imgData, imgArray);

        tflite.run(imgData, labelProbArray);

        ArrayList<Pair<Float, Integer>> toSort = new ArrayList<>();
        for (int i=0; i<labelList.size(); i++) {
            toSort.add(new Pair<Float, Integer>(labelProbArray[0][i], i));
        }

        Collections.sort(toSort, new Comparator<Pair<Float, Integer>>() {
            @Override
            public int compare(Pair<Float, Integer> o1, Pair<Float, Integer> o2) {
                float diff = o1.first - o2.first;
                if (diff < 0) return 1;
                else if (diff == 0) return 0;
                else return -1;
            }
        });

        for (int i=0; i<3; i++) {
            float actualPercent = toSort.get(i).first;
            int actualIndex = toSort.get(i).second;
            String ori = labelList.get(actualIndex);
            String fl = ori.substring(0,1);
            String cap = fl.toUpperCase();
            String newName = cap+ori.substring(1);
            outLabels[i][0].setText(newName);
            outLabels[i][1].setText(Float.toString(actualPercent*100) + '%');
        }
    }

    private void requestPermissions() {
        int PERMISSION_ALL = 1;
        String[] PERMISSIONS = {
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.READ_EXTERNAL_STORAGE,
                android.Manifest.permission.CAMERA
        };

        if (!Helper.hasPermissions(this, PERMISSIONS)) {
            ActivityCompat.requestPermissions(this, PERMISSIONS, PERMISSION_ALL);
        }
    }

}