package com.example.speciesclassification;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;

public class definition extends AppCompatActivity {

    private ArrayList<Species> species;
    private String targetName;
    private int index;

    private TextView title;
    private TextView taxon;
    private TextView common;
    private TextView USESA;
    private TextView SPROT;
    private TextView Endemic;
    private TextView GRank;
    private TextView SRank;
    private TextView SGCN;
    private TextView description;
    private TextView counties;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_definition);

        Intent intent = getIntent();
        species = (ArrayList<Species>) intent.getSerializableExtra("list");
        targetName = intent.getStringExtra("name");
        index = 0;
        for(int i=0; i<species.size(); i++) {
            if(species.get(i).getCName().equals(targetName) ||
                    species.get(i).getSName().equals(targetName)) {
                index = i;
                break;
            }
        }

        title = findViewById(R.id.tv_titleSpecies);
        taxon = findViewById(R.id.tv_taxon);
        common = findViewById(R.id.tv_common);
        USESA = findViewById(R.id.tv_USESA);
        SPROT = findViewById(R.id.tv_SPROT);
        Endemic = findViewById(R.id.tv_Endemic);
        GRank = findViewById(R.id.tv_GRank);
        SRank = findViewById(R.id.tv_SRank);
        SGCN = findViewById(R.id.tv_SGCN);
        description = findViewById(R.id.tv_description);
        counties = findViewById(R.id.tv_counties);

        title.setText(species.get(index).getSName());
        taxon.setText(species.get(index).getTaxon());
        common.setText(species.get(index).getCName());
        USESA.setText(species.get(index).getUSESA());
        SPROT.setText(species.get(index).getSPROT());
        Endemic.setText(species.get(index).getEndemic());
        GRank.setText(species.get(index).getGRank());
        SRank.setText(species.get(index).getSRank());
        SGCN.setText(species.get(index).getSGCN());
        description.setText(species.get(index).getDescription());
        counties.setText(species.get(index).getCounties());
    }
}