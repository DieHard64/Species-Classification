package com.example.speciesclassification;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import java.io.Serializable;
import java.util.ArrayList;

public class definition extends AppCompatActivity {

    private ArrayList<Species> species;
    private String targetName;
    private int index;

    private TextView title;
    private TextView taxon;
    private TextView common;
    private TextView USESA;
    private TextView SPROT;
    private TextView Endemic;
    private TextView GRank;
    private TextView SRank;
    private TextView SGCN;
    private TextView description;
    private TextView counties;

    private ImageButton btn_USESA;
    private ImageButton btn_SPROT;
    private ImageButton btn_Endemic;
    private ImageButton btn_GRank;
    private ImageButton btn_SRank;
    private ImageButton btn_SGCN;

    private Button capture_image;

    private AlertDialog.Builder builder;
    private AlertDialog alertDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_definition);

        Intent intent = getIntent();
        species = (ArrayList<Species>) intent.getSerializableExtra("list");
        targetName = intent.getStringExtra("name");
        index = 0;
        for(int i=0; i<species.size(); i++) {
            if(species.get(i).getCName().equals(targetName) ||
                    species.get(i).getSName().equals(targetName)) {
                index = i;
                break;
            }
        }

        title = findViewById(R.id.tv_titleSpecies);
        taxon = findViewById(R.id.tv_taxon);
        common = findViewById(R.id.tv_common);
        USESA = findViewById(R.id.tv_USESA);
        SPROT = findViewById(R.id.tv_SPROT);
        Endemic = findViewById(R.id.tv_Endemic);
        GRank = findViewById(R.id.tv_GRank);
        SRank = findViewById(R.id.tv_SRank);
        SGCN = findViewById(R.id.tv_SGCN);
        description = findViewById(R.id.tv_description);
        counties = findViewById(R.id.tv_counties);

        title.setText(species.get(index).getSName());
        taxon.setText("Taxon: "+species.get(index).getTaxon());
        common.setText("Common Name: "+species.get(index).getCName());
        USESA.setText("USESA Status: "+species.get(index).getUSESA());
        SPROT.setText("SPROT: "+species.get(index).getSPROT());
        Endemic.setText("Endemic: "+species.get(index).getEndemic());
        GRank.setText("Global Element Rank: "+species.get(index).getGRank());
        SRank.setText("State Element Rank: "+species.get(index).getSRank());
        SGCN.setText("SGCN Status: "+species.get(index).getSGCN());
        description.setText(species.get(index).getDescription());
        counties.setText("Counties Present: "+species.get(index).getCounties());

        btn_USESA = findViewById(R.id.btn_USESA);
        btn_SPROT = findViewById(R.id.btn_SPROT);
        btn_Endemic = findViewById(R.id.btn_Endemic);
        btn_GRank = findViewById(R.id.btn_GRank);
        btn_SRank = findViewById(R.id.btn_SRank);
        btn_SGCN = findViewById(R.id.btn_SGCN);
        capture_image = findViewById(R.id.btn_openCamera);

        btn_USESA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String description = getResources().getString(R.string.USESA_info);
                createAlertDialog("Your USESA status is: " + species.get(index).getUSESA(),description);
            }
        });
        btn_SPROT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String description = getResources().getString(R.string.SPROT_info);
                createAlertDialog("Your SPROT status is: " + species.get(index).getSPROT(),description);
            }
        });
        btn_Endemic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                createAlertDialog("Your Endemic status is: " + species.get(index).getEndemic(),"The endemic status determines " +
                        "whether or not the animal is restricted to a certain place." +
                        " Y for Yes and N for No");
            }
        });
        btn_GRank.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String description = getResources().getString(R.string.GRank_info);
                createAlertDialog("Your GRank is: " + species.get(index).getGRank(),description);
            }
        });
        btn_SRank.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String description = getResources().getString(R.string.SRank_info);
                createAlertDialog("Your SRank is: " + species.get(index).getSRank(),description);
            }
        });
        btn_SGCN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                createAlertDialog("Your SGCN status is: " + species.get(index).getSGCN(),"The Species of Greatest Conservation Need" +
                        " determines the abundance of a species and whether or not the animal is qualified for the Texas Conservation Action Plan." +
                        " Y for Qualified and N for Not Qualified");
            }
        });
        capture_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openCaption();
            }
        });
    }
    public void createAlertDialog(String title, String description) {
        builder = new AlertDialog.Builder(definition.this);
        View view = getLayoutInflater().inflate(R.layout.extra_info,null);
        TextView tv_info = view.findViewById(R.id.tv_info);
        tv_info.setText(description);
        builder.setView(view);
        alertDialog= builder.create();
        alertDialog.setTitle(title);
        alertDialog.show();
        alertDialog.getWindow().setLayout(400,500);
    }
    public void openCaption() {
        Intent intent = new Intent(definition.this, caption.class);
        intent.putExtra("list",(Serializable)species);
        startActivity(intent);
    }
}